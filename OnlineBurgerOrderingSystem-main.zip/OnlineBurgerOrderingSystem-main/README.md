Steps to use the cod:
1. Download & Install: XAMPP in C:\xampp (default)
2. Clone this repository in C:\xampp\htdocs
3. Run XAMPP and start "Apache" and "MySQL"
4. Open the link "localhost/phpmyadmin/"
5. Click on new at sidebar and create a database name "burgerorderingsystem"
6. After clicking database click import and select the file "burgerorderingsystem.sql"
4. Open the link "localhost/OnlineBurgerOrderingSystem/"
8. Now register and login!!

Admin Credentials: admin, admin@123

Assets: Images used in web

account.php: Users can see their details, and Customers can see their bookings.

burgers.php: Will be used by to update price of items, or add discounts. [NOT YET ADDED]

cart.php: Can see items added to cart, tax and net amount. And then can proceed to payment.php.

config.php: Configures database to website.

delivered.php: To update status of order to delivered.

index.php: Welcome page.

login.php: To login using username and password.

logout.php: To logout.

outForDelivery.php: To update status of order to Out for Delivery.

payment.php: To pay for order using card.

register.php: To create account.

sales.php: To manage orders.

store.php: To select items from and add them to cart.

style.css: The whole stylesheet of this project.

success.php: Payment successful page.
